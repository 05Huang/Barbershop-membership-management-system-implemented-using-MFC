#pragma once


// ChildDlg �Ի���

class ChildDlg : public CDialogEx
{
	DECLARE_DYNAMIC(ChildDlg)

public:
	ChildDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~ChildDlg();

// �Ի�������
	enum { IDD = IDD_ChildDlg };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	CString m_phone;
	CString m_sex;
//	int m_balance;
	CString m_grade;
	afx_msg void OnBnClickedButton1();
	CString m_name;
//	CString m_balance;
//	int m_balance;
	afx_msg void OnBnClickedButton2();
//	CString m_balance;
//	int m_balance;
//	CString m_balance;
	int m_balance;
};
