#pragma once


// ChildDlg2 �Ի���

class ChildDlg2 : public CDialogEx
{
	DECLARE_DYNAMIC(ChildDlg2)

public:
	ChildDlg2(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~ChildDlg2();

// �Ի�������
	enum { IDD = IDD_ChildDlg2 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
//	CString m_phone1;
	CString m_name;
//	CString m_sex1;
//	CString m_balance;
	CString m_grade;
//	CEdit m_phone;
//	CEdit m_sex;
	CString m_phone;
	CString m_sex;
//	int m_balance;
	CString m_balance;
};
