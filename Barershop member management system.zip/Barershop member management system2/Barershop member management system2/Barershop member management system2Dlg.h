#include"Datainterface.h"
// Barershop member management system2Dlg.h : ͷ�ļ�
//

#pragma once
#include "afxcmn.h"


// CBarershopmembermanagementsystem2Dlg �Ի���
class CBarershopmembermanagementsystem2Dlg : public CDialogEx
{
// ����
public:
	CBarershopmembermanagementsystem2Dlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_BARERSHOPMEMBERMANAGEMENTSYSTEM2_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CListCtrl m_list;
	CDatainterface Datainterface;
	CString strFilePath;
	afx_msg void OnBnClickedButton1();
	void UpdateList();
	afx_msg void OnBnClickedButton4();
	afx_msg void OnBnClickedButton5();
	afx_msg void OnBnClickedButton6();
	CString m_find;
	afx_msg void OnBnClickedButton7();
	afx_msg void OnBnClickedButton2();
	afx_msg void OnBnClickedButton3();
	bool Isopen;
	afx_msg void OnNcDestroy();
	afx_msg void OnBnClickedButton8();
	bool CheckPhoneNumberLength(LPCTSTR phoneNumber);
	afx_msg void OnBnClicked123();
};
