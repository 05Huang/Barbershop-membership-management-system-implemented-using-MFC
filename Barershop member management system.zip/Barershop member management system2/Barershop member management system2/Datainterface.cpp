#include "StdAfx.h"
#include "Datainterface.h"


CDatainterface::CDatainterface(void)
{
}


CDatainterface::~CDatainterface(void)
{
}

bool CDatainterface::Open(CString FilePath)
{
	ifstream in(FilePath,ios::in);
	if(in.is_open())
	{
		int num;
		in>>num;
		for(int i =0; i<num;i++)
		{
			Cinfo info;
			info.Load(in);
			Info.push_back(info);
		}
		return true;
	}
	return false;
}

void CDatainterface::Add(Cinfo info)
{
	Info.push_back(info);
}
void  CDatainterface::Del(int index)
{
	Info.erase(Info.begin()+index);
}
void CDatainterface::Clear()
{
	Info.clear();
}
void  CDatainterface::Amend(int index,Cinfo info)
{
	Info[index]=info;
}
int CDatainterface::yue(int index)
{
	return Info[index].m_balance;
}
Cinfo  CDatainterface::Find(string phone)
{
	for(int i =0;i<Info.size();i++)
	{
		if(Info[i].m_phone==phone)
		{
			return Info[i];
		}
	}
	return Cinfo(TEXT(""),TEXT(""),TEXT(""),-1,TEXT(""));
}
/*
Cinfo  CDatainterface::Find(int balance)
{
	for(int i =0;i<Info.size();i++)
	{
		if(Info[i].m_balance==balance)
		{
			return Info[i];
		}
	}
	return Cinfo(TEXT(""),TEXT(""),TEXT(""),-1,TEXT(""));
}*/

bool CDatainterface::Save(CString FilePath)
{
	ofstream out (FilePath,ios::out);
	if(out.is_open())
	{
		out<<Info.size()<<endl;
		for(int i=0;i<Info.size();i++)
		{
			Info[i].Save(out);
		}
		out.close();
		return true;
	}
	return false;
}