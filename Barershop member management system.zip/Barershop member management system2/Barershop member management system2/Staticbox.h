#pragma once


// CStaticbox �Ի���

class CStaticbox : public CDialogEx
{
	DECLARE_DYNAMIC(CStaticbox)

public:
	CStaticbox(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CStaticbox();

// �Ի�������
	enum { IDD = IDD_BARERSHOPMEMBERMANAGEMENTSYSTEM2_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()

public:
	virtual BOOL OnInitDialog();
};
