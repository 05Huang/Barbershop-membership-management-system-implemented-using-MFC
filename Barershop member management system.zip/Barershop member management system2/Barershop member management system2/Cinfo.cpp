#include "StdAfx.h"
#include "Cinfo.h"


Cinfo::Cinfo(void)
{
}

Cinfo::Cinfo(string phone,string name,string sex,int balance,string grade)
{
	this->m_balance = balance;
	this->m_grade =grade;
	this->m_name = name;
	this->m_phone =phone;
	this->m_sex = sex;

}

void Cinfo:: Load(ifstream&in)
{
	in>>m_phone;
	in>>m_name;
	in>>m_sex;
	in>>m_balance;
	in>>m_grade;
}
void Cinfo::Save(ofstream&out)
{
	out<<m_phone<<"\t";
	out<<m_name<<"\t";
	out<<m_sex<<"\t";
	out<<m_balance<<"\t";
	out<<m_grade<<"\n";
}
Cinfo::~Cinfo(void)
{
}
