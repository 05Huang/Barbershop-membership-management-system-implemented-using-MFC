#pragma once
class Cinfo
{
public:
	Cinfo();
	Cinfo(string m_phone,string m_name,string m_sex,int m_balance,string m_grade);
	~Cinfo();
	int m_balance;
	string m_name;
	string m_phone;
	string m_grade;
	string m_sex;
	void Load(ifstream&in);
	void Save(ofstream&out);
};

