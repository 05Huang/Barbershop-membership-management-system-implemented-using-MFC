#pragma once


// ChildDlg4 �Ի���

class ChildDlg4 : public CDialogEx
{
	DECLARE_DYNAMIC(ChildDlg4)

public:
	ChildDlg4(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~ChildDlg4();

// �Ի�������
	enum { IDD = IDD_ChildDlg4 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedCancel();
	int m_chongqian;
	afx_msg void OnBnClickedOk();
};
