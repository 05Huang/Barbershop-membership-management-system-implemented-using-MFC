#pragma once

#include"Cinfo.h";
class CDatainterface
{
public:
	CDatainterface(void);
	~CDatainterface(void);
	bool Open(CString  Filepath);
	void Add(Cinfo info);
	void Del(int index);
	void Amend(int index,Cinfo info);
	Cinfo Find(string phone);
	bool Save(CString Filepath);
	int yue(int index);
	void Clear();
	vector<Cinfo> Info;
};

