// Staticbox.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "Barershop member management system2.h"
#include "Staticbox.h"
#include "afxdialogex.h"
#include "Barershop member management system2.h"

// CStaticbox �Ի���

IMPLEMENT_DYNAMIC(CStaticbox, CDialogEx)

CStaticbox::CStaticbox(CWnd* pParent /*=NULL*/)
	: CDialogEx(CStaticbox::IDD, pParent)
{

}

CStaticbox::~CStaticbox()
{
}

void CStaticbox::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CStaticbox, CDialogEx)
END_MESSAGE_MAP()


// CStaticbox ��Ϣ��������


BOOL CStaticbox::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}
