// ChildDlg2.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "Barershop member management system2.h"
#include "ChildDlg2.h"
#include "afxdialogex.h"


// ChildDlg2 �Ի���

IMPLEMENT_DYNAMIC(ChildDlg2, CDialogEx)

ChildDlg2::ChildDlg2(CWnd* pParent /*=NULL*/)
	: CDialogEx(ChildDlg2::IDD, pParent)
	, m_phone(_T(""))
	, m_name(_T(""))
	, m_sex(_T(""))
	, m_balance(_T(""))
	, m_grade(_T(""))
{

	m_phone = _T("");
	m_sex = _T("");
	//  m_balance = 0;
	m_balance = _T("");
}

ChildDlg2::~ChildDlg2()
{
}

void ChildDlg2::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	//  DDX_Text(pDX, IDC_EDIT1, m_phone1);
	DDX_Text(pDX, IDC_EDIT6, m_name);
	//  DDX_Text(pDX, IDC_EDIT3, m_sex1);
	//  DDX_Text(pDX, IDC_EDIT4, m_balance);
	DDX_Text(pDX, IDC_EDIT5, m_grade);
	//  DDX_Control(pDX, IDC_EDIT1, m_phone);
	//  DDX_Control(pDX, IDC_EDIT3, m_sex);
	DDX_Text(pDX, IDC_EDIT1, m_phone);
	DDX_Text(pDX, IDC_EDIT3, m_sex);
	//  DDX_Text(pDX, IDC_EDIT4, m_balance);
	DDX_Text(pDX, IDC_EDIT4, m_balance);
}


BEGIN_MESSAGE_MAP(ChildDlg2, CDialogEx)
END_MESSAGE_MAP()


// ChildDlg2 ��Ϣ��������
